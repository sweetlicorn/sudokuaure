package org.moire.opensudoku.game.command;

/**
 * Created by spimanov on 29.10.17.
 */

public class CheckpointCommand extends AbstractCommand {

    public CheckpointCommand() {
    }

    @Override
    void execute() {
    }

    @Override
    void undo() {
    }

}
